﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetAPP.Models
{
    public class TweetMongoDBSettings : ITweetMongoDBSettings
    {
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }
        public string TweetCollectionName { get; set; }
        public string CommentCollectionName { get; set; }
        public string UserCollectionName { get; set; }
    }

    public interface ITweetMongoDBSettings
    {
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }
        public string TweetCollectionName { get; set; }
        public string CommentCollectionName { get; set; }
        public string UserCollectionName { get; set; }
    }
}

import { Tweet } from './tweet';

describe('Tweet', () => {
  it('should create an instance', () => {
    expect(new Tweet()).toBeTruthy();
  });
});

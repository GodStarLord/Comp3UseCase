export class UserComment {
    public tweetid: string;
    public username: string;
    public comments: string;
    public date: Date;
    public imageName: string;
}

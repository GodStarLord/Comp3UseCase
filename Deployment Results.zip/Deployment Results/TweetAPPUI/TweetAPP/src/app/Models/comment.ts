export class Comment {
    public tweetid: string;
    public username: string;
    public comments: string;
    public date: Date;
}

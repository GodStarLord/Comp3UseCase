import { UserComment } from './user-comment';

describe('UserComment', () => {
  it('should create an instance', () => {
    expect(new UserComment()).toBeTruthy();
  });
});

export class Token {
    public userId: string;
    public username: string;
    public tokens: string;
    public message: string;
}

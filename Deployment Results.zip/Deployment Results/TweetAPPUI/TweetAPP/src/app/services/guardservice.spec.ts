import { Guardservice } from './guardservice';

describe('Guardservice', () => {
  it('should create an instance', () => {
    expect(new Guardservice()).toBeTruthy();
  });
});
